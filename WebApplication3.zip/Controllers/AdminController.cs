﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
    
{
   
    public class AdminController : Controller
    {
        educationSystemEntities db = new educationSystemEntities();

        // GET: Admin
        public ActionResult Index()

        {
            return View();
        }
        public ActionResult AllCourse()
        {
            return View();
        }
        public ActionResult AddCourse()
        {
            return View();
        }
        public ActionResult AddCourse()
        {
            return View();
        }
        public ActionResult category()
        {
            return View();
        }
       
    }
}